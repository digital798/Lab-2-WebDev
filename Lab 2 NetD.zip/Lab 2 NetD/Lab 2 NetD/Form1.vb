﻿Option Strict On
Public Class Lab2
    Dim userInputValidate As Double 'declare all variables'
    Dim userInput As String
    Dim valid As Boolean
    Dim arrayGPA(5) As Integer
    Dim sum As Double
    Dim average As Double
    Private Sub calculatebtn_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        btnCalculate.Enabled = False 'Disable all text boxes and calculate button'
        txtCourse1.Enabled = False
        txtCourse2.Enabled = False
        txtCourse3.Enabled = False
        txtCourse4.Enabled = False
        txtCourse5.Enabled = False
        txtCourse6.Enabled = False
        For length As Integer = 0 To 5 'Declare the array'
            sum += arrayGPA(length)
        Next length
        average = Math.Round(sum / 6, 2)    'display the average letter and number grade'
        lblsemesterLetter.Text = gradeRange(average)
        lblSemesterGrade.Text = Convert.ToString(average)
    End Sub

    Public Function validation(ByVal input As String) As Boolean
        If Double.TryParse(input, userInputValidate) And userInputValidate >= 0 And userInputValidate <= 100 Then   'validate'
            valid = True
        Else valid = False
        End If
        Return valid
    End Function

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtCourse1.Clear()     'Clear all text boxes on reset'
        txtCourse2.Clear()
        txtCourse3.Clear()
        txtCourse4.Clear()
        txtCourse5.Clear()
        txtCourse6.Clear()
        txtoutputBox.Clear()
        lblcourse1Grade.Text = ""   'Clear all labels on reset'
        lblcourse2Grade.Text = ""
        lblcourse3Grade.Text = ""
        lblcourse4Grade.Text = ""
        lblcourse5Grade.Text = ""
        lblcourse6Grade.Text = ""
        lblsemesterLetter.Text = ""
        lblSemesterGrade.Text = ""
        sum = 0 'reset sum and average'
        average = 0
        txtCourse1.Focus()  'refocus on the first text box'
        btnCalculate.Enabled = True 're-enable all text boxes and calculate button'
        txtCourse1.Enabled = True
        txtCourse2.Enabled = True
        txtCourse3.Enabled = True
        txtCourse4.Enabled = True
        txtCourse5.Enabled = True
        txtCourse6.Enabled = True
    End Sub

    Private Function gradeRange(ByVal userInputValidate As Double) As String
        Dim letterGrade As String = ""  'set letter grades to certain ranges'
        Select Case userInputValidate
            Case 0 To 49
                letterGrade = "F"
            Case 50 To 52
                letterGrade = "D-"
            Case 53 To 56
                letterGrade = "D"
            Case 57 To 59
                letterGrade = "D+"
            Case 60 To 62
                letterGrade = "C-"
            Case 63 To 66
                letterGrade = "C"
            Case 67 To 69
                letterGrade = "C+"
            Case 70 To 72
                letterGrade = "B-"
            Case 73 To 76
                letterGrade = "B"
            Case 77 To 79
                letterGrade = "B+"
            Case 80 To 84
                letterGrade = "A-"
            Case 85 To 89
                letterGrade = "A"
            Case 90 To 100
                letterGrade = "A+"
        End Select
        Return letterGrade
    End Function
    Private Sub txtCourse1_TextChanged(sender As Object, e As EventArgs) Handles txtCourse1.TextChanged

    End Sub

    Private Sub txtCourse1_Leave(sender As Object, e As EventArgs) Handles txtCourse1.Leave

        valid = validation(txtCourse1.Text) 'Display course 1 text'

        If valid = False Then
            txtoutputBox.Text = "Please input a number between 0 and 100"
            txtCourse1.Focus()
            txtCourse1.Clear()
        ElseIf valid = True Then
            lblcourse1Grade.Text = gradeRange(userInputValidate)
            txtoutputBox.Clear()
            arrayGPA(0) = Convert.ToInt32(txtCourse1.Text)
        End If
    End Sub

    Private Sub txtCourse2_Leave(sender As Object, e As EventArgs) Handles txtCourse2.Leave

        valid = validation(txtCourse2.Text) 'Display course 2 text'

        If valid = False Then
            txtoutputBox.Text = "Please input a number between 0 and 100"
            txtCourse2.Focus()
            txtCourse2.Clear()
        ElseIf valid = True Then
            txtoutputBox.Clear()
            lblcourse2Grade.Text = gradeRange(userInputValidate)
            arrayGPA(1) = Convert.ToInt16(txtCourse2.Text)
        End If
    End Sub

    Private Sub txtCourse3_Leave(sender As Object, e As EventArgs) Handles txtCourse3.Leave

        valid = validation(txtCourse3.Text) 'Display course 3 text'

        If valid = False Then
            txtoutputBox.Text = "Please input a number between 0 and 100"
            txtCourse3.Focus()
            txtCourse3.Clear()
        ElseIf valid = True Then
            txtoutputBox.Clear()
            lblcourse3Grade.Text = gradeRange(userInputValidate)
            arrayGPA(2) = Convert.ToInt16(txtCourse3.Text)
        End If
    End Sub

    Private Sub txtCourse4_Leave(sender As Object, e As EventArgs) Handles txtCourse4.Leave

        valid = validation(txtCourse4.Text) 'Display course 4 text'

        If valid = False Then
            txtoutputBox.Text = "Please input a number between 0 and 100"
            txtCourse4.Focus()
            txtCourse4.Clear()
        ElseIf valid = True Then
            txtoutputBox.Clear()
            lblcourse4Grade.Text = gradeRange(userInputValidate)
            arrayGPA(3) = Convert.ToInt16(txtCourse4.Text)
        End If
    End Sub

    Private Sub txtCourse5_Leave(sender As Object, e As EventArgs) Handles txtCourse5.Leave

        valid = validation(txtCourse5.Text) 'Display course 5 text'

        If valid = False Then
            txtoutputBox.Text = "Please input a number between 0 and 100"
            txtCourse5.Focus()
            txtCourse5.Clear()
        ElseIf valid = True Then
            txtoutputBox.Clear()
            lblcourse5Grade.Text = gradeRange(userInputValidate)
            arrayGPA(4) = Convert.ToInt16(txtCourse5.Text)
        End If
    End Sub

    Private Sub txtCourse6_Leave(sender As Object, e As EventArgs) Handles txtCourse6.Leave

        valid = validation(txtCourse6.Text) 'Display course 6 text'

        If valid = False Then
            txtoutputBox.Text = "Please input a number between 0 and 100"
            txtCourse6.Focus()
            txtCourse6.Clear()
        ElseIf valid = True Then
            txtoutputBox.Clear()
            lblcourse6Grade.Text = gradeRange(userInputValidate)
            arrayGPA(5) = Convert.ToInt16(txtCourse6.Text)
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()  'Exit the application'
    End Sub
End Class