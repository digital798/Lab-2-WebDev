﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Lab2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblCourse1 = New System.Windows.Forms.Label()
        Me.lblCourse2 = New System.Windows.Forms.Label()
        Me.lblCourse3 = New System.Windows.Forms.Label()
        Me.lblCourse4 = New System.Windows.Forms.Label()
        Me.lblCourse5 = New System.Windows.Forms.Label()
        Me.lblCourse6 = New System.Windows.Forms.Label()
        Me.txtCourse1 = New System.Windows.Forms.TextBox()
        Me.txtCourse6 = New System.Windows.Forms.TextBox()
        Me.txtCourse4 = New System.Windows.Forms.TextBox()
        Me.txtCourse5 = New System.Windows.Forms.TextBox()
        Me.txtCourse3 = New System.Windows.Forms.TextBox()
        Me.txtCourse2 = New System.Windows.Forms.TextBox()
        Me.lblcourse1Grade = New System.Windows.Forms.Label()
        Me.lblcourse6Grade = New System.Windows.Forms.Label()
        Me.lblcourse5Grade = New System.Windows.Forms.Label()
        Me.lblcourse4Grade = New System.Windows.Forms.Label()
        Me.lblcourse3Grade = New System.Windows.Forms.Label()
        Me.lblcourse2Grade = New System.Windows.Forms.Label()
        Me.lblSemester = New System.Windows.Forms.Label()
        Me.lblSemesterGrade = New System.Windows.Forms.Label()
        Me.lblsemesterLetter = New System.Windows.Forms.Label()
        Me.txtoutputBox = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lblCourse1
        '
        Me.lblCourse1.Location = New System.Drawing.Point(21, 18)
        Me.lblCourse1.Name = "lblCourse1"
        Me.lblCourse1.Size = New System.Drawing.Size(76, 23)
        Me.lblCourse1.TabIndex = 0
        Me.lblCourse1.Text = "Course &1:"
        Me.ToolTip.SetToolTip(Me.lblCourse1, "Press Alt+1 to move to this input box.")
        '
        'lblCourse2
        '
        Me.lblCourse2.Location = New System.Drawing.Point(21, 46)
        Me.lblCourse2.Name = "lblCourse2"
        Me.lblCourse2.Size = New System.Drawing.Size(76, 23)
        Me.lblCourse2.TabIndex = 3
        Me.lblCourse2.Text = "Course &2:"
        Me.ToolTip.SetToolTip(Me.lblCourse2, "Press Alt+2 to move to this input box.")
        '
        'lblCourse3
        '
        Me.lblCourse3.Location = New System.Drawing.Point(21, 74)
        Me.lblCourse3.Name = "lblCourse3"
        Me.lblCourse3.Size = New System.Drawing.Size(76, 23)
        Me.lblCourse3.TabIndex = 6
        Me.lblCourse3.Text = "Course &3:"
        Me.ToolTip.SetToolTip(Me.lblCourse3, "Press Alt+3 to move to this input box.")
        '
        'lblCourse4
        '
        Me.lblCourse4.Location = New System.Drawing.Point(21, 102)
        Me.lblCourse4.Name = "lblCourse4"
        Me.lblCourse4.Size = New System.Drawing.Size(76, 23)
        Me.lblCourse4.TabIndex = 9
        Me.lblCourse4.Text = "Course &4:"
        Me.ToolTip.SetToolTip(Me.lblCourse4, "Press Alt+4 to move to this input box.")
        '
        'lblCourse5
        '
        Me.lblCourse5.Location = New System.Drawing.Point(21, 130)
        Me.lblCourse5.Name = "lblCourse5"
        Me.lblCourse5.Size = New System.Drawing.Size(76, 23)
        Me.lblCourse5.TabIndex = 12
        Me.lblCourse5.Text = "Course &5:"
        Me.ToolTip.SetToolTip(Me.lblCourse5, "Press Alt+5 to move to this input box.")
        '
        'lblCourse6
        '
        Me.lblCourse6.Location = New System.Drawing.Point(21, 158)
        Me.lblCourse6.Name = "lblCourse6"
        Me.lblCourse6.Size = New System.Drawing.Size(76, 23)
        Me.lblCourse6.TabIndex = 15
        Me.lblCourse6.Text = "Course &6:"
        Me.ToolTip.SetToolTip(Me.lblCourse6, "Press Alt+6 to move to this input box.")
        '
        'txtCourse1
        '
        Me.txtCourse1.Location = New System.Drawing.Point(103, 15)
        Me.txtCourse1.Name = "txtCourse1"
        Me.txtCourse1.Size = New System.Drawing.Size(95, 22)
        Me.txtCourse1.TabIndex = 1
        Me.ToolTip.SetToolTip(Me.txtCourse1, "Enter a numeric grade for course 1 here.")
        '
        'txtCourse6
        '
        Me.txtCourse6.Location = New System.Drawing.Point(103, 155)
        Me.txtCourse6.Name = "txtCourse6"
        Me.txtCourse6.Size = New System.Drawing.Size(95, 22)
        Me.txtCourse6.TabIndex = 16
        Me.ToolTip.SetToolTip(Me.txtCourse6, "Enter a numeric grade for course 6 here.")
        '
        'txtCourse4
        '
        Me.txtCourse4.Location = New System.Drawing.Point(103, 99)
        Me.txtCourse4.Name = "txtCourse4"
        Me.txtCourse4.Size = New System.Drawing.Size(95, 22)
        Me.txtCourse4.TabIndex = 10
        Me.ToolTip.SetToolTip(Me.txtCourse4, "Enter a numeric grade for course 4 here.")
        '
        'txtCourse5
        '
        Me.txtCourse5.Location = New System.Drawing.Point(103, 127)
        Me.txtCourse5.Name = "txtCourse5"
        Me.txtCourse5.Size = New System.Drawing.Size(95, 22)
        Me.txtCourse5.TabIndex = 13
        Me.ToolTip.SetToolTip(Me.txtCourse5, "Enter a numeric grade for course 5 here.")
        '
        'txtCourse3
        '
        Me.txtCourse3.Location = New System.Drawing.Point(103, 71)
        Me.txtCourse3.Name = "txtCourse3"
        Me.txtCourse3.Size = New System.Drawing.Size(95, 22)
        Me.txtCourse3.TabIndex = 7
        Me.ToolTip.SetToolTip(Me.txtCourse3, "Enter a numeric grade for course 3 here.")
        '
        'txtCourse2
        '
        Me.txtCourse2.Location = New System.Drawing.Point(103, 43)
        Me.txtCourse2.Name = "txtCourse2"
        Me.txtCourse2.Size = New System.Drawing.Size(95, 22)
        Me.txtCourse2.TabIndex = 4
        Me.ToolTip.SetToolTip(Me.txtCourse2, "Enter a numeric grade for course 2 here.")
        '
        'lblcourse1Grade
        '
        Me.lblcourse1Grade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblcourse1Grade.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblcourse1Grade.Location = New System.Drawing.Point(207, 16)
        Me.lblcourse1Grade.Name = "lblcourse1Grade"
        Me.lblcourse1Grade.Size = New System.Drawing.Size(95, 20)
        Me.lblcourse1Grade.TabIndex = 2
        Me.lblcourse1Grade.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ToolTip.SetToolTip(Me.lblcourse1Grade, "This displays the numeric grade entered for course 1 as a letter grade.")
        '
        'lblcourse6Grade
        '
        Me.lblcourse6Grade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblcourse6Grade.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblcourse6Grade.Location = New System.Drawing.Point(207, 157)
        Me.lblcourse6Grade.Name = "lblcourse6Grade"
        Me.lblcourse6Grade.Size = New System.Drawing.Size(95, 20)
        Me.lblcourse6Grade.TabIndex = 17
        Me.lblcourse6Grade.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ToolTip.SetToolTip(Me.lblcourse6Grade, "This displays the numeric grade entered for course 6 as a letter grade.")
        '
        'lblcourse5Grade
        '
        Me.lblcourse5Grade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblcourse5Grade.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblcourse5Grade.Location = New System.Drawing.Point(207, 129)
        Me.lblcourse5Grade.Name = "lblcourse5Grade"
        Me.lblcourse5Grade.Size = New System.Drawing.Size(95, 20)
        Me.lblcourse5Grade.TabIndex = 14
        Me.lblcourse5Grade.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ToolTip.SetToolTip(Me.lblcourse5Grade, "This displays the numeric grade entered for course 5 as a letter grade.")
        '
        'lblcourse4Grade
        '
        Me.lblcourse4Grade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblcourse4Grade.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblcourse4Grade.Location = New System.Drawing.Point(207, 101)
        Me.lblcourse4Grade.Name = "lblcourse4Grade"
        Me.lblcourse4Grade.Size = New System.Drawing.Size(95, 20)
        Me.lblcourse4Grade.TabIndex = 11
        Me.lblcourse4Grade.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ToolTip.SetToolTip(Me.lblcourse4Grade, "This displays the numeric grade entered for course 4 as a letter grade.")
        '
        'lblcourse3Grade
        '
        Me.lblcourse3Grade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblcourse3Grade.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblcourse3Grade.Location = New System.Drawing.Point(207, 73)
        Me.lblcourse3Grade.Name = "lblcourse3Grade"
        Me.lblcourse3Grade.Size = New System.Drawing.Size(95, 20)
        Me.lblcourse3Grade.TabIndex = 8
        Me.lblcourse3Grade.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ToolTip.SetToolTip(Me.lblcourse3Grade, "This displays the numeric grade entered for course 3 as a letter grade.")
        '
        'lblcourse2Grade
        '
        Me.lblcourse2Grade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblcourse2Grade.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblcourse2Grade.Location = New System.Drawing.Point(207, 45)
        Me.lblcourse2Grade.Name = "lblcourse2Grade"
        Me.lblcourse2Grade.Size = New System.Drawing.Size(95, 20)
        Me.lblcourse2Grade.TabIndex = 5
        Me.lblcourse2Grade.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ToolTip.SetToolTip(Me.lblcourse2Grade, "This displays the numeric grade entered for course 2 as a letter grade.")
        '
        'lblSemester
        '
        Me.lblSemester.Location = New System.Drawing.Point(21, 185)
        Me.lblSemester.Name = "lblSemester"
        Me.lblSemester.Size = New System.Drawing.Size(76, 23)
        Me.lblSemester.TabIndex = 18
        Me.lblSemester.Text = "Semester:"
        '
        'lblSemesterGrade
        '
        Me.lblSemesterGrade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSemesterGrade.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblSemesterGrade.Location = New System.Drawing.Point(103, 184)
        Me.lblSemesterGrade.Name = "lblSemesterGrade"
        Me.lblSemesterGrade.Size = New System.Drawing.Size(95, 24)
        Me.lblSemesterGrade.TabIndex = 19
        Me.lblSemesterGrade.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ToolTip.SetToolTip(Me.lblSemesterGrade, "This box displays the semester average as a numeric grade.")
        '
        'lblsemesterLetter
        '
        Me.lblsemesterLetter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblsemesterLetter.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblsemesterLetter.Location = New System.Drawing.Point(207, 184)
        Me.lblsemesterLetter.Name = "lblsemesterLetter"
        Me.lblsemesterLetter.Size = New System.Drawing.Size(95, 24)
        Me.lblsemesterLetter.TabIndex = 20
        Me.lblsemesterLetter.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ToolTip.SetToolTip(Me.lblsemesterLetter, "This box displays the semester average as a letter grade.")
        '
        'txtoutputBox
        '
        Me.txtoutputBox.Location = New System.Drawing.Point(4, 210)
        Me.txtoutputBox.Multiline = True
        Me.txtoutputBox.Name = "txtoutputBox"
        Me.txtoutputBox.ReadOnly = True
        Me.txtoutputBox.Size = New System.Drawing.Size(297, 161)
        Me.txtoutputBox.TabIndex = 21
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(24, 374)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(79, 23)
        Me.btnCalculate.TabIndex = 22
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(109, 374)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(79, 23)
        Me.btnReset.TabIndex = 23
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(194, 374)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(79, 23)
        Me.btnExit.TabIndex = 24
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Lab2
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(306, 400)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtoutputBox)
        Me.Controls.Add(Me.lblsemesterLetter)
        Me.Controls.Add(Me.lblSemesterGrade)
        Me.Controls.Add(Me.lblSemester)
        Me.Controls.Add(Me.lblcourse2Grade)
        Me.Controls.Add(Me.lblcourse3Grade)
        Me.Controls.Add(Me.lblcourse4Grade)
        Me.Controls.Add(Me.lblcourse5Grade)
        Me.Controls.Add(Me.lblcourse6Grade)
        Me.Controls.Add(Me.lblcourse1Grade)
        Me.Controls.Add(Me.txtCourse2)
        Me.Controls.Add(Me.txtCourse3)
        Me.Controls.Add(Me.txtCourse5)
        Me.Controls.Add(Me.txtCourse4)
        Me.Controls.Add(Me.txtCourse6)
        Me.Controls.Add(Me.txtCourse1)
        Me.Controls.Add(Me.lblCourse6)
        Me.Controls.Add(Me.lblCourse5)
        Me.Controls.Add(Me.lblCourse4)
        Me.Controls.Add(Me.lblCourse3)
        Me.Controls.Add(Me.lblCourse2)
        Me.Controls.Add(Me.lblCourse1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Lab2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Semester Average"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblCourse1 As Label
    Friend WithEvents lblCourse2 As Label
    Friend WithEvents lblCourse3 As Label
    Friend WithEvents lblCourse4 As Label
    Friend WithEvents lblCourse5 As Label
    Friend WithEvents lblCourse6 As Label
    Friend WithEvents txtCourse1 As TextBox
    Friend WithEvents txtCourse6 As TextBox
    Friend WithEvents txtCourse4 As TextBox
    Friend WithEvents txtCourse5 As TextBox
    Friend WithEvents txtCourse3 As TextBox
    Friend WithEvents txtCourse2 As TextBox
    Friend WithEvents lblcourse1Grade As Label
    Friend WithEvents lblcourse6Grade As Label
    Friend WithEvents lblcourse5Grade As Label
    Friend WithEvents lblcourse4Grade As Label
    Friend WithEvents lblcourse3Grade As Label
    Friend WithEvents lblcourse2Grade As Label
    Friend WithEvents lblSemester As Label
    Friend WithEvents lblSemesterGrade As Label
    Friend WithEvents lblsemesterLetter As Label
    Friend WithEvents txtoutputBox As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents ToolTip As ToolTip
End Class
